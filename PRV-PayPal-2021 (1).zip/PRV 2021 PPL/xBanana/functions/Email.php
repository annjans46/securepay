<?php
//XBANANA V3.3 Paypal Scama !!
                                                 

$xBanana_EMAIL = "onestnul@protonmail.com"; // PUT UR FUCKING E-MAIL BRO
$ChulSooRezHtml = "on"; // if do you want rezultaa text in html file, make "on" do you not want, make "off" FOR BIG REZULT X2 EMAIL + FTP 
?>
