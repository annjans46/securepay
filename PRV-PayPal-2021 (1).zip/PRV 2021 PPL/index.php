<?php
header("Location: ../xBanana")

?>